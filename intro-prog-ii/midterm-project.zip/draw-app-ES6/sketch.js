// globals
let toolbox
let options
// state
const state = []
// stamps
let starStamp

function preload() {
   starStamp = loadImage('../../assets/star-stamp.png')
}

function setup() {
   // get the canvas div element from the html
   const canvasElement = select('#canvas')
   // create a canvas to fill the canvas div
   const c = createCanvas(
      canvasElement.size().width,
      canvasElement.size().height
   )
   // set the parent html element to the canvas
   c.parent('canvas')
   // listen for click events in the header
   Listeners.clearSketch()
   Listeners.saveSketch(c)
   Listeners.undoAction()

   toolbox = new Toolbox()

   toolbox.addTool(new Pencil())
   toolbox.addTool(new Eraser())
   toolbox.addTool(new Line())
   toolbox.addTool(new Spray())
   toolbox.addTool(new Mirror())
   toolbox.addTool(new Stamp())
   toolbox.addTool(new Colours())

   options = new Optionbox()
}

function draw() {
   try {
      // draw according to the current tool
      toolbox.selectedTool.draw()
      // listen if the state is empty, if so, disable the undo button
      Listeners.disableButton()
   } catch (error) {
      console.log(error)
   }
}

function mousePressed() {
   // the max previous steps back is 20, if the state reach the maximum, remove the first element
   if (state.length === 20) state.shift()
   // store the current state
   state.push(get())
}

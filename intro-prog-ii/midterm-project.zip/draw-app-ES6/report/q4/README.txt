I have utilized the following external sources in my project:

-  Font Awesome Icons CDN: I incorporated Font Awesome icons from the CDN to enhance the visual appeal of the application.
-  P5.js: I referred to the P5.js library for creative coding and visualization, using its documentation and examples to implement various drawing functionalities.
-  Mozilla Developer Network (MDN) Docs: I consulted the MDN Docs for JavaScript to clarify syntax, explore built-in functions, and learn best practices.
class Helpers {
   static removeBorders(element) {
      // remove active borders from received elements
      const items = selectAll(element)
      items.forEach((item) => {
         item.style('border', 'none')
      })
   }

   static addBorder(id) {
      const element = select(`#${id}`)
      element.style('border', 'solid 2px #2e72c0')
   }

   static undoToPreviousState() {
      // if there are no previous states stored, do nothing
      if (state.length === 0) return
      // clear the canvas
      background(255)
      // draw the last state in the canvas
      image(state[state.length - 1], 0, 0)
      // remove the last state
      state.pop()
   }

   static mouseIsInsideCanvas() {
      return mouseX > 0 && mouseX < width && mouseY > 0 && mouseY < height
   }
}

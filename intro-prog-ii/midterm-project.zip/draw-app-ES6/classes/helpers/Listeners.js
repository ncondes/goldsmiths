class Listeners {
   static clearSketch() {
      select('#clear-button').mouseClicked(() => {
         // clear the screen by setting the background to white again
         background(255)
         // update the drawing state
         loadPixels()
      })
   }

   static saveSketch(canvas) {
      select('#save-button').mouseClicked(() => {
         // save the canvas to the local file system
         saveCanvas(canvas, 'myCanvas', 'jpg')
      })
   }

   static undoAction() {
      select('#undo-button').mouseClicked(() => {
         // the click in the undo button adds a state to the state, because of that we remove the last one
         state.pop()
         // call the undo method
         Helpers.undoToPreviousState()
      })
   }

   static disableButton() {
      const button = select('#undo-button')
      state.length === 0
         ? button.attribute('disabled', 'true')
         : button.removeAttribute('disabled')
   }
}

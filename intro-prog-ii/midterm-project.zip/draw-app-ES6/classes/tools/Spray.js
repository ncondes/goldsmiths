class Spray {
   icon = '<i class="fa-solid fa-spray-can"></i>'
   name = 'spray'
   points = 13
   spread = 10

   // if the mouse is pressed paint on the canvas
   // spread describes how far to spread the paint from the mouse pointer
   // points holds how many pixels of paint for each mouse press.
   draw() {
      if (mouseIsPressed && Helpers.mouseIsInsideCanvas()) {
         for (let i = 0; i < this.points; i++) {
            point(
               random(mouseX - this.spread, mouseX + this.spread),
               random(mouseY - this.spread, mouseY + this.spread)
            )
         }
      }
   }
}

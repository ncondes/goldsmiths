class Colours {
   name = 'colours'
   icon = '<i class="fa-solid fa-circle"></i>'

   constructor() {
      this.colorPicker = createColorPicker('#000000')
      this.colorPicker.style('border', 'none')
      // TODO: see how to position this
      this.colorPicker.position(36, 452)

      this.colorPicker.input(() => {
         fill(this.colorPicker.color())
         stroke(this.colorPicker.color())
      })
   }

   draw() {}
}

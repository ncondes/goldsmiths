class Pencil {
   icon = '<i class="fa-solid fa-pencil"></i>'
   name = 'pencil'
   previousMousePosition = { x: -1, y: -1 }
   weight = 2
   pencils = {
      'pencil-tiny': 0.5,
      'pencil-regular': 2,
      'pencil-bold': 6,
   }

   setPreviousMousePosition(x, y) {
      this.previousMousePosition.x = x
      this.previousMousePosition.y = y
   }

   draw() {
      if (mouseIsPressed && Helpers.mouseIsInsideCanvas()) {
         // if the mouse is pressed check if there is a previous position
         if (this.previousMousePosition.x === -1) {
            this.setPreviousMousePosition(mouseX, mouseY)
         } else {
            // draw a line from the previous position to the current
            push()
            strokeWeight(this.weight)
            line(
               this.previousMousePosition.x,
               this.previousMousePosition.y,
               mouseX,
               mouseY
            )
            pop()
            // update the previous position
            this.setPreviousMousePosition(mouseX, mouseY)
         }
      } else {
         // if the user has released the mouse we set the previousMouse back to -1
         this.setPreviousMousePosition(-1, -1)
      }
   }

   buildOption(id, variation) {
      return `<div class="options-item" id="${id}">
            <i class="fa-solid fa-minus ${variation}"></i>
         </div>`
   }

   buildHTML() {
      const sizes = ['fa-2xs', 'fa-sm', 'fa-xl']
      // create the html to be injected in the options element
      return Object.keys(this.pencils).reduce((acc, curr, i) => {
         acc += this.buildOption(curr, sizes[i])
         return acc
      }, '')
   }

   handleOptionClick() {
      // generate the click handler for each option item
      Object.entries(this.pencils).forEach(([id, value]) => {
         select(`#${id}`).mouseClicked(() => {
            this.weight = value
            Helpers.removeBorders('.options-item')
            Helpers.addBorder(id)
         })
      })
   }

   options() {
      select('.options').html(this.buildHTML())
      this.handleOptionClick()

      // get the current size and add the border to that item
      for (const key in this.pencils) {
         if (this.pencils[key] === this.weight) {
            Helpers.addBorder(key)
            break
         }
      }
   }

   unselect() {
      loadPixels()
      select('.options').html('')
   }
}

class Stamp {
   name = 'stamp'
   icon = '<i class="fa-solid fa-stamp"></i>'
   size = createSlider(0, 100, 50)
   amount = createSlider(1, 50, 1)

   constructor() {
      this.size.style('display', 'none')
      this.amount.style('display', 'none')
   }

   draw() {
      if (mouseIsPressed && Helpers.mouseIsInsideCanvas()) {
         if (this.amount.value() === 1) {
            const x = mouseX - this.size.value() / 2
            const y = mouseY - this.size.value() / 2

            image(starStamp, x, y, this.size.value(), this.size.value())
         } else {
            for (let i = 0; i < this.amount.value(); i++) {
               const x = random(
                  mouseX - this.size.value() / 2 - this.size.value(),
                  mouseX - this.size.value() / 2 + this.size.value()
               )
               const y = random(
                  mouseY - this.size.value() / 2 - this.size.value(),
                  mouseY - this.size.value() / 2 + this.size.value()
               )
               image(starStamp, x, y, this.size.value(), this.size.value())
            }
         }
      }
   }

   options() {
      select('.options').html(
         `<div class="options-item" style="cursor:auto">
            <span class="options-item__label">Size</span>
         </div>
         <div class="options-item" style="background:transparent; box-shadow:none;">
         </div>
         <div class="options-item" style="cursor:auto">
            <span class="options-item__label">#</span>
         </div>
         <div class="options-item" style="background:transparent; box-shadow:none">
         </div>
         `
      )

      this.size.style('display', 'block')
      this.amount.style('display', 'block')

      this.size.position(width + 161, 188)
      this.size.style('width', '3rem')
      this.size.parent('options')

      this.amount.position(width + 161, 300)
      this.amount.style('width', '3rem')
      this.amount.parent('options')
   }

   unselect() {
      loadPixels()
      select('.options').html('')
   }
}

class Line {
   icon = '<i class="fa-solid fa-minus fa-rotate-90"></i>'
   name = 'line'
   startMousePosition = { x: -1, y: -1 }
   isDrawing = false

   setStartMousePosition(x, y) {
      this.startMousePosition.x = x
      this.startMousePosition.y = y
   }

   draw() {
      if (mouseIsPressed && Helpers.mouseIsInsideCanvas()) {
         // if the mouse is pressed check if there is a start position to start the line
         if (this.startMousePosition.x === -1) {
            this.setStartMousePosition(mouseX, mouseY)
            this.isDrawing = true
            loadPixels()
         } else {
            // draw a line from the starting position to the mouse position
            updatePixels()
            line(
               this.startMousePosition.x,
               this.startMousePosition.y,
               mouseX,
               mouseY
            )
         }
      } else if (this.isDrawing) {
         // return values to default
         this.isDrawing = false
         this.setStartMousePosition(-1, -1)
      }
   }
}

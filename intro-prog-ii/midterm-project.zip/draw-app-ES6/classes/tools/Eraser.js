class Eraser {
   name = 'eraser'
   icon = '<i class="fa-solid fa-eraser"></i>'
   size = 50
   erasers = {
      'eraser-small': 20,
      'eraser-normal': 50,
      'eraser-big': 100,
   }

   draw() {
      if (mouseIsPressed && Helpers.mouseIsInsideCanvas()) {
         // if mouse is pressed draw a white square
         push()
         strokeWeight(0)
         fill(255)
         rect(
            mouseX - this.size / 2,
            mouseY - this.size / 2,
            this.size,
            this.size
         )
         pop()
      }
   }

   buildOption(id, variation) {
      return `<div class="options-item" id="${id}">
            <i class="fa-regular fa-square ${variation}"></i>
         </div>`
   }

   buildHTML() {
      const sizes = ['fa-2xs', 'fa-sm', 'fa-xl']
      // create the html to be injected in the options element
      return Object.keys(this.erasers).reduce((acc, curr, i) => {
         acc += this.buildOption(curr, sizes[i])
         return acc
      }, '')
   }

   handleOptionClick() {
      // generate the click handler for each option item
      Object.entries(this.erasers).forEach(([id, value]) => {
         select(`#${id}`).mouseClicked(() => {
            this.size = value
            Helpers.removeBorders('.options-item')
            Helpers.addBorder(id)
         })
      })
   }

   options() {
      select('.options').html(this.buildHTML())
      this.handleOptionClick()

      // get the current size and add the border to that item
      for (const key in this.erasers) {
         if (this.erasers[key] === this.size) {
            Helpers.addBorder(key)
            break
         }
      }
   }

   unselect() {
      loadPixels()
      select('.options').html('')
   }
}

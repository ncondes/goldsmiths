class Optionbox {
   options = []
   selectedOption = null

   addOption(option) {
      this.options.push(option)
      // add option to the optionss array
      // insert the sidebar item into the html
      const optionItem = createDiv(option.icon)
      // add props to the html element created
      optionItem.class('options-item')
      optionItem.id(`${option.name}-options-item`)
      optionItem.parent('options')

      // bind this to the handler click function
      //   const handleClick = this.toolbarItemClick.bind(this)

      optionItem.mouseClicked(() => {
         console.log('CLICK')
      })
      // if there is no tool selected, make this tool the selected one.
      if (this.selectedOption == null) {
         console.log('need to select an option')
         //  this.selectTool(tool.name)
      }
   }
}
